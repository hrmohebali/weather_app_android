package com.example.weatherapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.example.weatherapp.api.WeatherApi
import com.example.weatherapp.databinding.ActivityMainBinding
import com.example.weatherapp.model.CurrentWeatherResponse
import com.example.weatherapp.repository.WeatherRepository
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.squareup.picasso.Picasso
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var repo: WeatherRepository
    private val apiKey = "ec1a379576952457aceaea9047bf7a99"
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            getWeatherByLocation()
        } else {
            showError("دسترسی مکان داده نشد.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY }
        val httpClient = OkHttpClient.Builder().addInterceptor(logging).build()
        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(httpClient)
            .build()
        val api = retrofit.create(WeatherApi::class.java)
        repo = WeatherRepository(api)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        binding.btnCity.setOnClickListener {
            val city = binding.etCity.text.toString().trim()
            if (city.isNotEmpty()) {
                fetchWeatherByCity(city)
            } else {
                showError("نام شهر را وارد کنید")
            }
        }
        binding.btnCoord.setOnClickListener {
            val lat = binding.etLat.text.toString().toDoubleOrNull()
            val lon = binding.etLon.text.toString().toDoubleOrNull()
            if (lat == null || lon == null) {
                showError("مقدار مختصات معتبر وارد کنید")
            } else {
                fetchWeatherByCoord(lat, lon)
            }
        }
        binding.btnByLocation.setOnClickListener {
            requestLocationAndShowWeather()
        }
    }

    private fun fetchWeatherByCity(city: String) {
        lifecycleScope.launch {
            try {
                val result = repo.getWeatherByCity(city, apiKey)
                if (result.isSuccessful && result.body() != null) {
                    showWeather(result.body()!!)
                } else {
                    showError("کد: ${result.code()}\n${result.errorBody()?.string()}")
                }
            } catch(e: Exception) {
                showError("EX: ${e.message}")
            }
        }
    }

    private fun fetchWeatherByCoord(lat: Double, lon: Double) {
        lifecycleScope.launch {
            try {
                val result = repo.getWeatherByCoord(lat, lon, apiKey)
                if (result.isSuccessful && result.body() != null) {
                    showWeather(result.body()!!)
                } else {
                    showError("کد: ${result.code()}\n${result.errorBody()?.string()}")
                }
            } catch(e: Exception) {
                showError("EX: ${e.message}")
            }
        }
    }

    // گرفتن و نمایش آب‌وهوا با مختصات گوشی
    private fun requestLocationAndShowWeather() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED) {
            getWeatherByLocation()
        } else {
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }
    private fun getWeatherByLocation() {
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                fetchWeatherByCoord(location.latitude, location.longitude)
            } else {
                showError("مختصات پیدا نشد! GPS را روشن کنید.")
            }
        }.addOnFailureListener {
            showError("خواندن مختصات با خطا مواجه شد.")
        }
    }

    private fun showWeather(weather: CurrentWeatherResponse) {
        val w = weather.weather.firstOrNull()
        binding.tvDesc.text = "آسمان: ${w?.description ?: "نامشخص"}\nباد: ${weather.wind?.speed ?: "-"}m/s"
        binding.tvTemp.text = "دما: ${weather.main.temp}، احساس: ${weather.main.feels_like}℃"
        if(w != null) {
            Picasso.get().load("https://openweathermap.org/img/wn/${w.icon}@4x.png").into(binding.ivIcon)
        } else binding.ivIcon.setImageDrawable(null)
    }
    private fun showError(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
        binding.tvDesc.text = "❌ $text"
        binding.tvTemp.text = ""
        binding.ivIcon.setImageDrawable(null)
    }
}
