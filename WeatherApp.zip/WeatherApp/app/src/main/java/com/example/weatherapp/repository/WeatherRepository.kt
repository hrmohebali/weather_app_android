package com.example.weatherapp.repository

import com.example.weatherapp.api.WeatherApi

class WeatherRepository(val api: WeatherApi) {
    suspend fun getWeatherByCity(city: String, apiKey: String) =
        api.getCurrentWeatherByCity(city, apiKey)

    suspend fun getWeatherByCoord(lat: Double, lon: Double, apiKey: String) =
        api.getCurrentWeatherByCoord(lat, lon, apiKey)
}
