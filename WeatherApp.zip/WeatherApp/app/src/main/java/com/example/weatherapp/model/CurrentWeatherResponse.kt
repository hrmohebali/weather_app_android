package com.example.weatherapp.model

data class CurrentWeatherResponse(
    val name: String?,
    val weather: List<WeatherDesc>,
    val main: MainBlock,
    val wind: WindBlock?
)

data class WeatherDesc(
    val main: String,
    val description: String,
    val icon: String
)
data class MainBlock(
    val temp: Double,
    val feels_like: Double,
    val temp_min: Double,
    val temp_max: Double,
    val pressure: Int,
    val humidity: Int
)
data class WindBlock(
    val speed: Double?,
    val deg: Int?
)
